﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AssocAddEdit.Controllers
{
    // Attention 0X - Country view model class
    public class ClassificationBase
    {
        public int Id { get; set; }

        [Required, StringLength(200)]
        [Display(Name = "Classification Name")]
        public string Name { get; set; }
    }
}