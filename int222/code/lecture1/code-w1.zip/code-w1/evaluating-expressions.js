/* instruction: copy the content of this file into Firefox Scratchpad, and click "Run". */ 

var x = prompt("Enter a number."); 
x = x + 2; 
alert ("The value of x is " + x); 

x = 2 * x; 
alert("The new value of x is now " + x); 

x = x + 1; 
alert("x is now " + x); 

alert("x divided by 3 is: " + x/3); 
