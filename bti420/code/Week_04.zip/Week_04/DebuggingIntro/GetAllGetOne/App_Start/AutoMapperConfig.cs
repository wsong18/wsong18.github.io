﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// new...
using AutoMapper;

namespace GetAllGetOne
{
    public static class AutoMapperConfig
    {
        public static void RegisterMappings()
        {
            // Disable AutoMapper v4.2.x warnings
#pragma warning disable CS0618
            // Add map creation statements here
            // Mapper.CreateMap< FROM , TO >();

            // Attention - Error - mapping error, missing AutoMapper map

            //Mapper.CreateMap<Models.Customer, Controllers.CustomerBase>();

            Mapper.CreateMap<Controllers.CustomerBase, Controllers.CustomerEditContactInfoForm>();
            
            Mapper.CreateMap<Controllers.CustomerAdd, Models.Customer>();
#pragma warning restore CS0618
        }
    }
}