### Week 1 code examples

**Strings**

Learn about the .NET Framework "String" class.

Features:
- it's a console app
- popular and often-used string methods

**Conversions**

String - number conversions.

Features:
- it's a console app
- string-to-number, int and double
- number-to-string, int and double
- includes parsing and null tests

**Collections**

Introduction to a generic List<T> collection.

Features:
- it's a console app
- collections of strings, numbers, and objects
