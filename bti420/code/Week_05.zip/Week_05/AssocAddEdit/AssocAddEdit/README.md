﻿Project information

(for the programmer - replace this with useful information)
